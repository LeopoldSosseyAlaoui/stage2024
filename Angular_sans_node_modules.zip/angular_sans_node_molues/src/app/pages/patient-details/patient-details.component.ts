import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebserviceService } from '../../services/webservice.service';
import { HospitalisationDTO } from '../../models/hospitalisation.dto';
import { ConsultationDTO } from '../../models/consultation.dto';
@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.css']
})
export class PatientDetailsComponent implements OnInit {
  indnb :number | null = null;
  hospitalisations: HospitalisationDTO[] = [];
  consultations: ConsultationDTO[] = [];

  constructor(
    private route: ActivatedRoute,
    private webservicService: WebserviceService
  ) {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.indnb = Number(params['id']);
      }
    });
  }

  ngOnInit(): void{
    console.log('On init 2');
    if (this.indnb) {
      this.webservicService.hospitalisation_consultation_by_identite(this.indnb).subscribe((datas) => {
        this.hospitalisations = datas.hospitalisations;
        this.consultations = datas.consultations;
        console.log(this.consultations)
      });
    }
  }
}
