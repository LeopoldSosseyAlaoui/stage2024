import { Component, OnInit } from '@angular/core';
import { WebserviceService } from '../../services/webservice.service';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { IdentiteDTO } from '../../models/identite.dto';
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink, CommonModule, MatPaginatorModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
  providers: [WebserviceService]
})
export class HomeComponent implements OnInit {
  title = 'angular-app';
  searchTerm: string = '';
  patients:IdentiteDTO[] = [];
  filteredPatients: IdentiteDTO[] = [];
  page: number = 0;
  size: number = 4;
  totalPatients = 0;
  constructor(private webserviceService: WebserviceService) {
    
   }

  // angular material: se concentrer sur les fonctionnalités
  // pagination: diviser de grandes collections de données en pages plus petites.
  ngOnInit() {
    this.loadPatients(this.page, this.size);
  }

  loadPatients(pageIndex: number, pageSize: number) {
    this.webserviceService.identites(pageIndex + 1, pageSize).subscribe({
      next: (datas) => {
        this.patients = datas.patients;
        // this.hospitalisations_list = datas.hosin_list || [];
        // this.consultations_list = datas.cslin_list || [];
        this.totalPatients = datas.totalPatients; // Assuming your API returns totalCount
        console.log(this.patients[0]);
      },
      error: (error) => {
        console.error('Error loading patients:', error);
      }
    });
  }

  onPageChange(event: PageEvent) {
    console.log('Page event:', event);
    this.page = event.pageIndex;
    this.size = event.pageSize;
    this.loadPatients(this.page, this.size);
  }
}

