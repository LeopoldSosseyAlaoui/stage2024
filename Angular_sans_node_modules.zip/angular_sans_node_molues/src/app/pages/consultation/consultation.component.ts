import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Chart } from 'chart.js/auto';
import { WebserviceService } from '../../services/webservice.service';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-consultation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './consultation.component.html',
  styleUrl: './consultation.component.css'
})
export class ConsultationComponent {
  average_consultations: number = 0;
  
  avg_consultations_per_year: number = 0;
  consultations_per_year: { [key: string]: number } = {};
  constructor(
    private webserviceService: WebserviceService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    console.log('On init');
    this.webserviceService.statistic_consultation().subscribe((datas) => {
      this.consultations_per_year = datas.consultations_per_year;
      this.avg_consultations_per_year = datas.avg_consultations_per_year
      this.average_consultations = datas.average_consultations
      
      
      if (isPlatformBrowser(this.platformId)) {
        this.createChart();
      }
    });
  }
  createChart(): void {
    const labels = Object.keys(this.consultations_per_year);
    const data = Object.values(this.consultations_per_year);

    new Chart('stat_cons', {
      type: 'line',  // ou 'bar', 'pie', etc.
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Consultations annuelles',
            data: data,
            borderColor: '#3e95cd',
            fill: false
          }
        ]
      },
      options: {
        scales: {
          x: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Année'  // Titre de l'axe X
            }
          },
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Consultations'  // Titre de l'axe Y
            }
          }
        },
        plugins: {
          title: {
            display: true,
            text: 'Statistiques des consultations'  // Titre du graphique
          }
        }
      }
    });
  }

}
