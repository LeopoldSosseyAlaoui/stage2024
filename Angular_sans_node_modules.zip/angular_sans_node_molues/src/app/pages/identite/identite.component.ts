import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { WebserviceService } from '../../services/webservice.service';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Chart } from 'chart.js/auto';
import { FaitMedicalComponent } from '../fait-medical/fait-medical.component';

@Component({
  selector: 'app-identite',
  standalone: true,
  imports: [RouterLink, CommonModule],
  templateUrl: './identite.component.html',
  styleUrls: ['./identite.component.css'],
})
export class IdentiteComponent implements OnInit {
  average_age: number = 0;
  male_percentage: number = 0;
  female_percentage: number = 0;
  papeete_percentage: number = 0;
  decade_percentages: { [key: string]: number } = {};
  cps_percentage: number = 0;
  

  constructor(
    private webserviceService: WebserviceService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    console.log('On init');
    this.webserviceService.statistic_identite().subscribe((datas) => {
      this.average_age = datas.average_age;
      this.male_percentage = datas.male_percentage;
      this.female_percentage = datas.female_percentage;
      this.decade_percentages = datas.age_distribution_by_decade;
      this.cps_percentage = datas.cps_percentage;
      this.papeete_percentage = datas.papeete_percentage;
      
      console.log("ages:", this.decade_percentages);

      // Appeler la méthode pour créer le graphique après que les données sont chargées
      if (isPlatformBrowser(this.platformId)) {
        this.createChart();
      }
    });
  }

  createChart(): void {
    if (!isPlatformBrowser(this.platformId)) //vérifie si le code s'exécute dans un navigateur
    {
      return;
    }

    // Attendre que les données soient chargées
    if (!Object.keys(this.decade_percentages).length) {
      setTimeout(() => this.createChart(), 100);
      return;
    }

    const ctx = (document.getElementById('myChart') as HTMLCanvasElement).getContext('2d');
    if (!ctx) {
      console.error('Could not get context for canvas');
      return;
    }

    const labels = Object.keys(this.decade_percentages);
    const data = Object.values(this.decade_percentages);

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: "Pourcentage de patients",
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1,
          data: data
        }]
      },
      options: {
        responsive: true,
        plugins: {
          title: {
            display: true,
            text: 'Distributions des âges des patients'
          }
        },
        scales: {
          x: {
            display: true,
            title: {
              display: true,
              text: 'Âge'
            }
          },
          y: {
            display: true,
            title: {
              display: true,
              text: 'Percentage'
            },
            beginAtZero: true,
            
          }
          
          
        }
      }
    });
  }
}
