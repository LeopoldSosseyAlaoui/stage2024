import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Chart } from 'chart.js/auto';
import { WebserviceService } from '../../services/webservice.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-fait-medical',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './fait-medical.component.html',
  styleUrl: './fait-medical.component.css'
})
export class FaitMedicalComponent {
  ratio: number = 0;
  total_internal_consultations: number = 0;
  total_external_consultations: number = 0;
  consultations_by_service: { [key: string]: number } = {};
  constructor(
    private webserviceService: WebserviceService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    console.log('On init');
    this.webserviceService.statistic_FaitMedical().subscribe((datas) => {
      this.ratio = datas.ratio;
      this.total_internal_consultations = datas.total_internal_consultations;
      this.total_external_consultations = datas.total_external_consultations;
      this.consultations_by_service = datas.consultations_by_service
      // Appeler la méthode pour créer le graphique après que les données sont chargées
      if (isPlatformBrowser(this.platformId)) {
        this.createChart();
      }
    });
  }
  createChart(): void {
    const labels = Object.keys(this.consultations_by_service);
    const data = Object.values(this.consultations_by_service);

    new Chart('stat_cons_par_service', {
      type: 'line',  // ou 'bar', 'pie', etc.
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Consultations par services',
            data: data,
            borderColor: '#3e95cd',
            fill: false
          }
        ]
      },
      options: {
        scales: {
          x: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Services'  // Titre de l'axe X
            }
          },
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Consultations'  // Titre de l'axe Y
            }
          }
        },
        plugins: {
          title: {
            display: true,
            text: 'Statistiques des consultations par services'  // Titre du graphique
          }
        }
      }
    });
  }

}
