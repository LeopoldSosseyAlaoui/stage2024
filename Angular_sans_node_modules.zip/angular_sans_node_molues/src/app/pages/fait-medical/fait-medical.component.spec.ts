import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FaitMedicalComponent } from './fait-medical.component';

describe('FaitMedicalComponent', () => {
  let component: FaitMedicalComponent;
  let fixture: ComponentFixture<FaitMedicalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FaitMedicalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FaitMedicalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
