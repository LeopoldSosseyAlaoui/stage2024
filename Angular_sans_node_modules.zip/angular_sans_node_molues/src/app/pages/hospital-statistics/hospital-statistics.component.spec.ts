import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HospitalStatisticsComponent } from './hospital-statistics.component';

describe('HospitalStatisticsComponent', () => {
  let component: HospitalStatisticsComponent;
  let fixture: ComponentFixture<HospitalStatisticsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HospitalStatisticsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HospitalStatisticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
