import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import { WebserviceService } from '../../services/webservice.service';
import { RouterLink, RouterModule } from '@angular/router';
import { Chart } from 'chart.js/auto';

@Component({
  selector: 'app-hospital-statistics',
  standalone: true,
  imports: [RouterLink, CommonModule, RouterModule],
  templateUrl: './hospital-statistics.component.html',
  styleUrls: ['./hospital-statistics.component.css']
})
export class HospitalStatisticsComponent implements OnInit {
  average_hospitalization_duration: number = 0;
  median_hospitalization_duration: number = 0;
  duration_distribution: { [key: string]: number } = {};

  constructor(
    private webserviceService: WebserviceService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    this.webserviceService.statistic_hospitalisation().subscribe((datas) => {
      this.average_hospitalization_duration = datas.average_hospitalization_duration;
      console.log('durée moyenne:', this.average_hospitalization_duration)
      this.duration_distribution = datas.duration_distribution;
      this.median_hospitalization_duration = datas.median_hospitalization_duration;
      // Appeler la méthode pour créer le graphique après que les données sont chargées
      if (isPlatformBrowser(this.platformId)) {
        this.createChart();
      }
    });
  }

  createChart(): void {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }

    if (!Object.keys(this.duration_distribution).length) {
      setTimeout(() => this.createChart(), 100);
      return;
    }

    const ctx = (document.getElementById('myChart') as HTMLCanvasElement).getContext('2d');
    if (!ctx) {
      console.error('Could not get context for canvas');
      return;
    }

    const labels = Object.keys(this.duration_distribution);
    const data = Object.values(this.duration_distribution);

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: "Nombre d'hospitlisations",
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1,
          data: data
        }]
      },
      options: {
        responsive: true,
        plugins: {
          title: {
            display: true,
            text: 'Distribution des hospitalisations'
          }
        },
        scales: {
          x: {
            display: true,
            title: {
              display: true,
              text: 'Nombre de jours'
            }
          },
          y: {
            display: true,
            title: {
              display: true,
              text: "Hospitalisations"
            },
            beginAtZero: true,
          }
        }
      }
    });
  }
}
