import { Routes } from '@angular/router';
import { PatientDetailsComponent } from './pages/patient-details/patient-details.component';
import { HomeComponent } from './pages/home/home.component';
import { IdentiteComponent } from './pages/identite/identite.component';
import { ConsultationComponent } from './pages/consultation/consultation.component';
import { HospitalStatisticsComponent } from './pages/hospital-statistics/hospital-statistics.component';
import {FaitMedicalComponent} from './pages/fait-medical/fait-medical.component';
export const routes: Routes = [
    {
        path: "statistiqueConsultation",
        component: ConsultationComponent,

    },
    {
        path:'details/:id',
        component: PatientDetailsComponent,
    },
    {
        path: "statistiqueIdentite",
        component: IdentiteComponent,

    },
    
    {
        path: "statistiqueHospitalisation",
        component: HospitalStatisticsComponent,
    },
    {
        path: "statistiqueGlobale",
        component: FaitMedicalComponent,
    },
    {
        path: "**",
        component: HomeComponent,
    },
];