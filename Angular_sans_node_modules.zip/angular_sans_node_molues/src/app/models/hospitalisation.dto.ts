// src/app/models/hospitalisation.dto.ts

export class HospitalisationDTO {
    constructor(
      public hosnb: number,
      public hosin: number,
      public hosst: string,
      public hosoy: number,
      public hosom: number,
      public hosod: number,
      public hossy: number,
      public hossm: number,
      public hossd: number,
      public hosrs: string,
      public hosuy: number,
      public hosum: number,
      public hosud: number,
      public hosus: string,
      public hosmo?: string
    ) {}
  }
  