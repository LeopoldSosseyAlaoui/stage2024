export class IdentiteDTO {
    constructor(
      public indnb: number,
      public indnm: string,
      public indsn: string,
      public indoi: string,
      public indyy: number,
      public indmm: number,
      public inddd: number,
      public indsx: string,
      public indmt: number,
      public indnn: string,
      public inddn: number,
      public induy: number,
      public indum: number,
      public indud: number,
      public indne?: string,
      public indbp?: string,
      public indus?: string
    ) {}
  }