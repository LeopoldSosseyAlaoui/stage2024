export class ConsultationDTO {
    constructor(
      public cslcr: number,
      public cslnb: number,
      public cslin: number, 
      public cslsv: string,
      public cslps: string,
      public cslst: string,
      public csloy: number,
      public cslom: number,
      public cslod: number,
      public csluy: number,
      public cslum: number,
      public cslud: number,
      public cslus: string
    ) {}
  }