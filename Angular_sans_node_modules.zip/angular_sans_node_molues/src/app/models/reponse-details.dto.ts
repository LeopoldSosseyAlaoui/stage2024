import { ConsultationDTO } from "./consultation.dto";
import { HospitalisationDTO } from "./hospitalisation.dto";
import { IdentiteDTO } from "./identite.dto";
export interface ReponseDetailsDto {
    consultations: ConsultationDTO[],
    hospitalisations: HospitalisationDTO[],
    
}
export interface ReponseIdentiteDTO {
    identites: IdentiteDTO[],
}