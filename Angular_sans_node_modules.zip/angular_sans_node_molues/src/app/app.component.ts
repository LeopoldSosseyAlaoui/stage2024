import { Component } from '@angular/core';
import { RouterModule, RouterOutlet } from '@angular/router';
import { IdentiteComponent } from "./pages/identite/identite.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterModule, IdentiteComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: []
})
export class AppComponent {
  title = 'Hello World'; 
}
