import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { IdentiteDTO } from '../models/identite.dto';
import { ReponseDetailsDto } from '../models/reponse-details.dto';


@Injectable({
  providedIn: 'root'
})
export class WebserviceService {
  readonly API_URL = '/api'; 
  readonly ENDPOINT_PATIENTS = "/statistic/identites"
  readonly ENDPOINT_HOS_CSL = "/statistic/hospitalisations_et_consultations_du_patient"
  readonly ENDPOINT_STAT_ID = "/statistic/statistic_identite"
  readonly ENDPOINT_STAT_CSL = "/statistic/statistic_consultation"
  readonly ENDPOINT_STAT_HOS= "/statistic/statistic_hospitalisation"
  readonly ENDPOINT_STAT_FaitMedical= "/statistic/statistic_FaitMedical"
  constructor(private http: HttpClient) { }
  
  identites(page: number, size: number): Observable<{ patients: IdentiteDTO[], totalPatients: number }> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString());
    return this.http.get<any>(this.API_URL + this.ENDPOINT_PATIENTS, { params }).pipe(
      map(response => ({
        patients: response.patients.map((item: any) => new IdentiteDTO(
          item.indnb,
          item.indnm,
          item.indsn,
          item.indoi,
          item.indyy,
          item.indmm,
          item.inddd,
          item.indsx,
          item.indmt,
          item.indnn,
          item.inddn,
          item.induy,
          item.indum,
          item.indud,
          item.indne,
          item.indbp,
          item.indus
        )),
        totalPatients: response.totalPatients
      })),

    );
  }
  hospitalisation_consultation_by_identite(indnb: number): Observable<ReponseDetailsDto> {
    return this.http.get<ReponseDetailsDto>(`${this.API_URL}${this.ENDPOINT_HOS_CSL}/${indnb}`);
  }
  statistic_identite(): Observable<any> {
    return this.http.get<any>(`${this.API_URL}${this.ENDPOINT_STAT_ID}`);
  }
  statistic_consultation():Observable<any>{
    return this.http.get<any>(`
      ${this.API_URL}${this.ENDPOINT_STAT_CSL}
      `);
  }
  statistic_hospitalisation():Observable<any>{
    return this.http.get<any>(`${this.API_URL}${this.ENDPOINT_STAT_HOS}`);
  }
  statistic_FaitMedical():Observable<any>{
    return this.http.get<any>(`${this.API_URL}${this.ENDPOINT_STAT_FaitMedical}`);
  }
  
}
