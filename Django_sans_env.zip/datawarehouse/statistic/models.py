from django.db import models

class DimIdentite(models.Model):
    indnb = models.IntegerField(primary_key=True, db_column='indnb')
    indnm = models.CharField(max_length=255, db_column='indnm')
    indne = models.CharField(max_length=255, null=True, blank=True, db_column='indne')
    indsn = models.CharField(max_length=255, db_column='indsn')
    indoi = models.CharField(max_length=255, db_column='indoi')
    indyy = models.IntegerField(db_column='indyy')
    indmm = models.IntegerField(db_column='indmm')
    inddd = models.IntegerField(db_column='inddd')
    indbp = models.CharField(max_length=255, null=True, blank=True, db_column='indbp')
    indsx = models.CharField(max_length=255, db_column='indsx')
    indmt = models.FloatField(db_column='indmt')
    indnn = models.CharField(max_length=255, db_column='indnn')
    inddn = models.IntegerField(db_column='inddn')
    induy = models.IntegerField(db_column='induy')
    indum = models.IntegerField(db_column='indum')
    indud = models.IntegerField(db_column='indud')
    indus = models.CharField(max_length=255, null=True, blank=True, db_column='indus')

    class Meta:
        db_table = 'DimIdentite'
        managed = False  # Indique à Django de ne pas gérer cette table

    def __str__(self):
        return f"{self.indnb}" #renvoie l'id

class DimHospitalisation(models.Model):
    hosnb = models.BigAutoField(primary_key=True)
    hosin = models.IntegerField()
    hosst = models.CharField(max_length=255)
    hosoy = models.IntegerField()
    hosom = models.IntegerField()
    hosod = models.IntegerField()
    hossy = models.IntegerField()
    hossm = models.IntegerField()
    hossd = models.IntegerField()
    hosmo = models.CharField(max_length=255, null=True, blank=True)
    hosrs = models.CharField(max_length=255)
    hosuy = models.IntegerField()
    hosum = models.IntegerField()
    hosud = models.IntegerField()
    hosus = models.CharField(max_length=255)
    class Meta:
        db_table = 'DimHospitalisation'
        managed = False  
    def __str__(self):
        return f"DimHospitalisation {self.hosnb}"

class DimConsultation(models.Model):
    cslcr = models.IntegerField()
    cslnb = models.BigAutoField(primary_key=True)
    cslin = models.IntegerField()
    cslsv = models.CharField(max_length=255)
    cslps = models.CharField(max_length=255)
    cslst = models.CharField(max_length=255)
    csloy = models.IntegerField()
    cslom = models.IntegerField()
    cslod = models.IntegerField()
    csluy = models.IntegerField()
    cslum = models.IntegerField()
    cslud = models.IntegerField()
    cslus = models.CharField(max_length=255)
    class Meta:
        db_table = 'DimConsultation'
        managed = False 
    def __str__(self):
        return f"DimConsultation {self.cslnb}"

class FaitMedical(models.Model):
    id_fait = models.AutoField(primary_key=True, db_column='id_fait')
    indnb = models.ForeignKey(DimIdentite, on_delete=models.CASCADE, db_column='indnb', related_name='faits_medicaux')
    hosnb = models.ForeignKey(DimHospitalisation, on_delete=models.CASCADE, db_column='hosnb', related_name='faits_medicaux', null=True, blank=True)
    cslnb = models.ForeignKey(DimConsultation, on_delete=models.CASCADE, db_column='cslnb', related_name='faits_medicaux', null=True, blank=True)
    motif = models.CharField(max_length=255)
    date_entree = models.DateField(null=True, blank=True)
    date_sortie = models.DateField(null=True, blank=True)
    service = models.CharField(max_length=255)
    date = models.DateField(null=True, blank=True)

    class Meta:
        db_table = 'FaitMedical'
        managed = False  # Indique à Django de ne pas gérer cette table

    def __str__(self):
        return f"FaitMedical {self.id_fait}"
