from django.shortcuts import render
from django.http import HttpResponse, Http404, JsonResponse
from .models import DimIdentite
from .models import DimHospitalisation
from .models import DimConsultation
from django.template import loader
from django import template
from django.core.paginator import Paginator
from datetime import datetime
from collections import defaultdict
import pandas as pd
from django.db.models import Count, Q, F
from datetime import date, timedelta
# Create your views here.
from django.http import HttpResponse
from .models import FaitMedical


def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")

def identites(request):
    page = int(request.GET.get('page', 1))
    size = int(request.GET.get('size', 10))

    patients = DimIdentite.objects.all()

    paginator = Paginator(patients, size)
    patients_page = paginator.get_page(page)

    response = {
        'patients': [
            {
                'indnb': patient.indnb,
                'indnm': patient.indnm,
                'indne': patient.indne,
                'indsn': patient.indsn,
                'indoi': patient.indoi,
                'indyy': patient.indyy,
                'indmm': patient.indmm,
                'inddd': patient.inddd,
                'indbp': patient.indbp,
                'indsx': patient.indsx,
                'indmt': patient.indmt,
                'indnn': patient.indnn,
                'inddn': patient.inddn,
                'induy': patient.induy,
                'indum': patient.indum,
                'indud': patient.indud,
                'indus': patient.indus
            }
            for patient in patients_page
        ],
        'totalPatients': paginator.count
    }

    return JsonResponse(response)

def hospitalisation_consultation_by_identite(request, indnb):
    try:
        identite = DimIdentite.objects.get(pk=indnb)
    except DimIdentite.DoesNotExist:
        raise Http404("Identite record with the given ID does not exist")

    hospitalisations = DimHospitalisation.objects.filter(hosin=identite.pk)
    consultations = DimConsultation.objects.filter(cslin=identite.pk)

    if not hospitalisations.exists() and not consultations.exists():
        raise Http404("No hospitalisations or consultations found for the provided Identite record")

    response = {
        'indnb': identite.indnb,
        'hospitalisations': [
            {
                'hosnb': hos.hosnb,
                'hosst': hos.hosst,
                'hosoy': hos.hosoy,
                'hosom': hos.hosom,
                'hosod': hos.hosod,
                'hossy': hos.hossy,
                'hossm': hos.hossm,
                'hossd': hos.hossd,
                'hosmo': hos.hosmo,
                'hosrs': hos.hosrs,
                'hosuy': hos.hosuy,
                'hosum': hos.hosum,
                'hosud': hos.hosud,
                'hosus': hos.hosus
            } for hos in hospitalisations
        ],
        'consultations': [
            {
                'cslcr': csl.cslcr,
                'cslnb': csl.cslnb,
                'cslsv': csl.cslsv,
                'cslps': csl.cslps,
                'cslst': csl.cslst,
                'csloy': csl.csloy,
                'cslom': csl.cslom,
                'cslod': csl.cslod,
                'csluy': csl.csluy,
                'cslum': csl.cslum,
                'cslud': csl.cslud,
                'cslus': csl.cslus
            } for csl in consultations
        ]
    }

    return JsonResponse(response, safe=False)


def statistic_identite(request):
    identites = DimIdentite.objects.all()
    today = datetime.today()
    ages = []
    ages_male = []
    ages_female = []
    cps_count = 0
    decade_counts = defaultdict(int)
    papeete_count = 0  # Compteur pour les personnes nées à Papeete
    nb_femme=0
    nb_homme=0
    for identite in identites:
        try:
            birthdate = datetime(identite.indyy, identite.indmm, identite.inddd)
            age = today.year - birthdate.year - ((today.month, today.day) < (birthdate.month, birthdate.day))
            ages.append(age)
            if identite.indsx == 'M':
                ages_male.append(age)
                nb_homme+=1
            elif identite.indsx == 'F':
                ages_female.append(age)
                nb_femme+=1
            decade = (age // 10) * 10
            
            decade_counts[decade] += 1
            if identite.indus == '*CPS*':
                cps_count += 1
            if identite.indbp == 'PAPEETE':  # Vérification du lieu de naissance
                papeete_count += 1
        except ValueError:
            # Ignorer les enregistrements avec des dates invalides
            continue
    
    if ages:
        average_age = sum(ages) / len(ages)
    else:
        average_age = None  # ou 0, ou toute autre valeur par défaut appropriée

    if ages_male:
        average_age_male = sum(ages_male) / len(ages_male)
    else:
        average_age_male = None  # ou 0, ou toute autre valeur par défaut appropriée

    if ages_female:
        average_age_female = sum(ages_female) / len(ages_female)
    else:
        average_age_female = None  # ou 0, ou toute autre valeur par défaut appropriée
    
    total_patients = len(ages)
    decade_percentages = {decade: (count / total_patients) * 100 for decade, count in decade_counts.items()}
    cps_percentage = (cps_count / total_patients) * 100 if total_patients > 0 else 0
    papeete_percentage = (papeete_count / total_patients) * 100 if total_patients > 0 else 0
    male_percentage = (nb_homme / total_patients) * 100
    female_percentage = (nb_femme / total_patients) * 100
    response = {
        "average_age": average_age,
        "average_age_male": average_age_male,
        "average_age_female": average_age_female,
        "age_distribution_by_decade": decade_percentages,
        "cps_percentage": cps_percentage,
        "papeete_percentage": papeete_percentage,
        "nb_femme": nb_femme,
        "nb_homme": nb_homme,
        "male_percentage": male_percentage,
        "female_percentage": female_percentage
    }
    
    return JsonResponse(response)

#nombre de consultation par an
#graphe evolution du nombre de consultation par an
def statistic_consultation(request):
    consultations = DimConsultation.objects.all().values('cslin', 'cslnb')
    
    # Convertir en DataFrame Pandas
    df = pd.DataFrame.from_records(consultations)

    # Grouper par 'cslin' et compter les valeurs distinctes de 'cslnb'
    distinct_counts = df.groupby('cslin')['cslnb'].nunique()

    # Calculer la moyenne des consultations par patients ayants des consultations
    average_consultations = distinct_counts.mean()
    
    # Récupérer le nombre de consultations par an
    consultations_per_year = (
        DimConsultation.objects
        .values('csloy')  # Assurez-vous que 'csloy' est bien le champ correspondant à l'année
        .annotate(count=Count('cslnb'))  # Compter le nombre de consultations par année
        .order_by('csloy')  # Optionnel: trier par année
    )

    # Calculer le nombre moyen de consultations par an<
    total_consultations = sum(entry['count'] for entry in consultations_per_year)
    num_years = consultations_per_year.count()
    avg_consultations_per_year = total_consultations / num_years if num_years > 0 else 0

    # Construire la réponse en JSON
    response = {
        "average_consultations": average_consultations,
        "avg_consultations_per_year": avg_consultations_per_year,
        "consultations_per_year": {entry['csloy']: entry['count'] for entry in consultations_per_year}
    }

    return JsonResponse(response)
#duree moyenne
#distribution des durees 
def statistic_hospitalisation(request):
    
    hospitalizations = DimHospitalisation.objects.all()
    total_duration = timedelta()
    valid_count = 0
    duration_list = []

    for hospitalization in hospitalizations:
        try:
            entry_date = date(hospitalization.hosoy, hospitalization.hosom, hospitalization.hosod)
            exit_date = date(hospitalization.hossy, hospitalization.hossm, hospitalization.hossd)
            duration = exit_date - entry_date
            duration_days = duration.days

            # Ajouter à la liste des durées pour la distribution
            duration_list.append(duration_days)
            
            total_duration += duration
            valid_count += 1
        except ValueError:
            # Ignore records with invalid dates
            continue

    # Calcul de la durée moyenne en jours, en tenant compte des enregistrements valides
    average_duration_in_days = (total_duration.total_seconds() / (60 * 60 * 24)) / valid_count if valid_count > 0 else 0
     # Calcul de la médiane des durées d'hospitalisation
    duration_list.sort()
    if valid_count > 0:
        median_duration_in_days = duration_list[valid_count // 2] if valid_count % 2 != 0 else (duration_list[valid_count // 2 - 1] + duration_list[valid_count // 2]) / 2
    else:
        median_duration_in_days = 0
    # Distribution des durées sous forme de dictionnaire avec de nouveaux intervalles
    duration_distribution = {
        '0-5 days': 0,
        '6-10 days': 0,
        '11-20 days': 0,
        '21-30 days': 0,
        '31-100 days': 0,
        '101-365 days': 0,
        '365+ days': 0
    }

    for duration in duration_list:
        if duration <= 5:
            duration_distribution['0-5 days'] += 1
        elif duration <= 10:
            duration_distribution['6-10 days'] += 1
        elif duration <= 20:
            duration_distribution['11-20 days'] += 1
        elif duration <= 30:
            duration_distribution['21-30 days'] += 1
        elif duration <= 100:
            duration_distribution['31-100 days'] += 1
        elif duration <= 365:
            duration_distribution['101-365 days'] += 1
        else:
            duration_distribution['365+ days'] += 1

    # Renvoie le résultat en JSON, incluant la durée moyenne et la distribution des durées
    return JsonResponse({
        'average_hospitalization_duration': average_duration_in_days,
        'median_hospitalization_duration': median_duration_in_days,
        'duration_distribution': duration_distribution
    })
#ratio consultation d'hospitalisation / consultation externe au cours du temps


def statistic_FaitMedical(request):
    # Filtrer et compter les consultations internes
    internal_consultations = FaitMedical.objects.filter(
        date__gte=F('date_entree'),  # date plus grande que date entree
        date__lte=F('date_sortie')   # date plus petite que date sortie
    ).values('indnb').annotate(internal_count=Count('id_fait'))
    
    # Filtrer et compter les consultations externes
    external_consultations = FaitMedical.objects.filter(
        Q(date__lt=F('date_entree')) | Q(date__gt=F('date_sortie')) | Q(date_entree__isnull=True) | Q(date_sortie__isnull=True)
    ).values('indnb').annotate(external_count=Count('id_fait'))

    # Calculer le total des consultations internes et externes
    total_internal = sum(item['internal_count'] for item in internal_consultations)
    total_external = sum(item['external_count'] for item in external_consultations)

    # Calculer le ratio moyen global
    ratio = total_internal / total_external if total_external > 0 else None

    # Comptage des consultations par service
    consultations_by_service = (FaitMedical.objects
                            .values('service')
                            .annotate(service_count=Count('id_fait'))
                            .filter(service_count__gt=10)
                            .exclude(service__isnull=True)
                            .order_by('-service_count')[:10])
    
    # Préparer les données pour le JSON
    consultations_by_service_dict = {item['service']: item['service_count'] for item in consultations_by_service}

    # Retourner les résultats sous forme de réponse JSON
    return JsonResponse({
        'ratio': ratio,
        'total_internal_consultations': total_internal,
        'total_external_consultations': total_external,
        'consultations_by_service': consultations_by_service_dict,
    })



