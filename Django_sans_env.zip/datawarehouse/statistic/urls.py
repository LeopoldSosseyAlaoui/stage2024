from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path('identites', views.identites, name='identite'),   
    path('hospitalisations_et_consultations_du_patient/<int:indnb>', views.hospitalisation_consultation_by_identite, name='hospitalisations_by_identite'),
    path('statistic_identite', views.statistic_identite, name='statistic_idenitite'),
    path('statistic_consultation', 
         views.statistic_consultation, 
         name='statistic_consultation'),
    path('statistic_hospitalisation', views.statistic_hospitalisation, name='statistic_hospitalisation'),
    path('statistic_FaitMedical', views.statistic_FaitMedical, name='statistic_FaitMedical')
]