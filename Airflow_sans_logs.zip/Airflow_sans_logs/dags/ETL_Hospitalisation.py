import logging
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from utils.db_utils import connect_to_db, fetch_all_data, insert_or_update_data, get_intersection_values
from utils.etl_utils import generate_upsert_query
import pandas as pd
import os

# Define default arguments
default_args = {
    'owner': 'leopold',
    'start_date': datetime(2024, 6, 21),
}

hostname = 'host.docker.internal'  # adresse du pc et non du conteneur
port = 5432
username = 'postgres'
password = 'postgre'

# Extraction function
def extraction():
    try:
        # Connection à la base de données 'hospitalisation'
        conn_hospitalisation = connect_to_db(hostname, port, 'hospitalisation', username, password)
        logging.info("Connections to PostgreSQL DBs successful")

        # Extractionde de la table 'Hospitalisation'
        results_hospitalisation = fetch_all_data(conn_hospitalisation, "Hospitalisation")

        logging.info("Fetched results from all source DBs")

        conn_hospitalisation.close()

        # Connection à la base de données 'identite'
        conn_identite = connect_to_db(hostname, port, 'identite', username, password)
        logging.info("Connections to PostgreSQL DBs successful")

        # Extraction de la table 'Identite'
        results_identite = fetch_all_data(conn_identite, "Identite")

        logging.info("Fetched results from all source DBs")

        conn_identite.close()
        return {
            'hospitalisation': results_hospitalisation,
            'identite': results_identite,
        }

    except Exception as e:
        logging.error("Error connecting to PostgreSQL DBs", exc_info=True)
        return {}
   

#Loading function
# Loading function
def chargement(ti):
    try:
        data = ti.xcom_pull(task_ids='une_simple_extraction')
        if not data:
            logging.error("No data pulled from XCom")
            return
        
        
        hospitalisation_data = data['hospitalisation']
        identite_data = data['identite']

        # Connection to databases
        conn_datawarehouse = connect_to_db(hostname, port, 'datawarehouse', username, password)
        logging.info("Connection to Data Warehouse DB successful")

        # Récupérer les données aux intersections des 2 tables, ie HOSIN == INDNB
        
        intersection_values, difference_values = get_intersection_values(0, 1, identite_data, hospitalisation_data)
        
        # Génération de la requête d'insertion/mise à jour
        columns_hospitalisation = [
            "HOSNB", "HOSIN", "HOSST", "HOSOY", "HOSOM", "HOSOD", "HOSSY", "HOSSM", 
            "HOSSD", "HOSMO", "HOSRS", "HOSUY", "HOSUM", "HOSUD", "HOSUS"
        ]
        query = generate_upsert_query("HOSNB", "Hospitalisation", columns_hospitalisation)

        
        # Application de la requete dans la base datawarehouse
        insert_or_update_data(conn_datawarehouse, query, intersection_values) 
        for value in difference_values:
            logging.info(f'error: {value} ne correspond à aucun élément de identite')


        
        # Chemin de sortie 
        output_path = os.path.join('/opt/airflow/data/output', 'difference_hospitalisation.csv')
        difference = pd.DataFrame(difference_values)
        logging.info(f'Dimension de difference: {difference.shape}')
        # Message de log avant de sauvegarder le fichier
        logging.info(f"Enregistrement des données dans le fichier Excel : {output_path}")

        try:
        
            difference.to_csv(output_path, index=False)
            # Message de log après la sauvegarde
            logging.info(f"Les données ont été enregistrées avec succès dans le fichier Excel : {output_path}")
        except Exception as e:
            logging.error(f"Erreur lors de l'enregistrement des données dans le fichier Excel : {e}")
        conn_datawarehouse.commit()
        conn_datawarehouse.close()
        logging.info("Data loaded into Data Warehouse successfully")

    except Exception as e:
        logging.error("Error loading data into Data Warehouse", exc_info=True)

# Define the DAG, fréquence=toutes les 2 heures
with DAG("ETL_Hospitalisation", default_args=default_args, catchup=False, schedule_interval='0 */2 * * *') as dag:
    extraction_task = PythonOperator(
        task_id='une_simple_extraction',
        python_callable=extraction,
    )
    chargement_task = PythonOperator(
        task_id='un_simple_chargement',
        python_callable=chargement,
    )
extraction_task >> chargement_task