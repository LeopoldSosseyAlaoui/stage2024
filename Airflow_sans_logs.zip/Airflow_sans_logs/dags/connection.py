import logging
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import psycopg2
from airflow.providers.postgres.hooks.postgres import PostgresHook

# Define default arguments
default_args = {
    'owner': 'leopold',
    'start_date': datetime(2024, 6, 21),
}
hostname = 'host.docker.internal'  # adresse du pc et non du conteneur
port = 5432
database = 'identite'
username = 'postgres'
password = 'postgre'

def extraction():
    try:
        conn = psycopg2.connect(
            host=hostname,
            port=port,
            database = database,
            user=username,
            password=password,
        )
        logging.info("Connection to PostgreSQL DB successful")
        # Create a cursor
        cursor = conn.cursor()
        # Execute a simple query
        cursor.execute('SELECT * FROM public."Identite"')
        # Fetch and print the results
        results = cursor.fetchall()
        logging.info(f"Fetched results: {results}")
        # Close the cursor and connection
        cursor.close()
        conn.close()
    except Exception as e:
        logging.error("Error connecting to PostgreSQL DB", exc_info=True)





with DAG("connection", default_args=default_args, catchup=False, schedule_interval=None) as dag:
    extraction = PythonOperator(
        task_id='une_simple_extraction',
        python_callable=extraction,
    )

extraction
