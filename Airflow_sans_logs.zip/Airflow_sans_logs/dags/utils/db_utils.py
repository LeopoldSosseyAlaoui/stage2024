import psycopg2
import logging
from datetime import datetime
def connect_to_db(hostname, port, database, username, password):
    try:
        conn = psycopg2.connect(
            host=hostname,
            port=port,
            database=database,
            user=username,
            password=password,
        )
        logging.info(f"Connexion à la base de données {database} réussie")
        return conn
    except Exception as e:
        logging.error(f"Erreur lors de la connexion à la base de données {database}: {e}")
        return None

def fetch_all_data(connection, table_name):
    try:
        cursor = connection.cursor()
        query = f'SELECT * FROM public."{table_name}"'
        cursor.execute(query)
        results = cursor.fetchall()
        logging.info("Données extraites avec succès")
        return results
    except Exception as e:
        logging.error(f"Erreur lors de l'extraction des données: {e}")
        return []
    finally:
        cursor.close()
#parcourir la table hospitalisation si fk existe alors insert xmax different 0 sinon xmax = 0
#
def get_intersection_values(pk_index, fk_index, pk_data, fk_data):
    try:
        # Transformer les résultats en dictionnaires pour une jointure plus facile
        pk_dict = {row[pk_index]: row for row in pk_data}
        intersection = []
        difference = []

        for row in fk_data:
            if row[fk_index] in pk_dict:
                intersection.append(row)
            else:
                difference.append(row)
        return intersection, difference

    except Exception as e:
        logging.error(f"Erreur lors de l'extraction des données: {e}")
        return []

    

# execute la requête dans la base cible

def insert_or_update_data(connection, query, values):
    cursor = connection.cursor()
    try:
        for value in values:
            try:
                logging.info(f"Exécution de la requête pour les valeurs : {value}")
                cursor.execute(query, value)
                
                connection.commit()
                # Récupérer la valeur retournée
                returned_value = cursor.fetchone()
                if returned_value is None:
                    logging.info("Pas de changement")
                else:
                    action, primary_key = returned_value
                    if action == 'insert':
                        logging.info(f"Insertion réussie, clé primaire : {primary_key}")
                    else:
                        logging.info(f"Mise à jour réussie, clé primaire : {primary_key}")
                    logging.info(f"action : {action}, primary_key : {primary_key}")
            except psycopg2.IntegrityError as integrity_error:
                connection.rollback()
                logging.error(f"Erreur d'intégrité (conflit de clé primaire ?) pour les valeurs {value} : {integrity_error}")
            except Exception as e:
                connection.rollback()
                logging.error(f"Erreur lors de l'insertion/mise à jour des données pour les valeurs {value} : {e}")
    finally:
        cursor.close()

    
def extract_date(record, start_index):
    try:
        year = int(record[start_index])
        month = int(record[start_index + 1])
        day = int(record[start_index + 2])
        return datetime(year, month, day)
    except ValueError:
        return None  # Retourne None si la conversion échoue
    
def is_valid_date(date):
    return date is not None