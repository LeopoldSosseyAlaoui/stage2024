
'''
Insert les données de %S dans la table cible 
    si il y a un conflit de clé primaire:
        remplacer les données présentes par données dans %S
    sinon
        pas de changement
'''
import logging
'''def generate_upsert_query(primary_key, table_name, columns):
    # Génération de la partie VALUES (%s, %s, ...)
    values_placeholders = ', '.join(['%s'] * len(columns))
    # Génération de la partie ON CONFLICT (ID) DO UPDATE SET
    update_set = ', '.join([f"{col} = EXCLUDED.{col}" for col in columns[1:]])
    # Génération de la partie WHERE
    where_clause = ' OR '.join([f'public."{table_name}".{col} IS DISTINCT FROM EXCLUDED.{col}' for col in columns[1:]])
    
    # Requête d'insertion/mise à jour
    query = f"""
        INSERT INTO public."{table_name}" ({', '.join(columns)})
        VALUES ({values_placeholders})
        ON CONFLICT ({primary_key}) DO UPDATE SET
            {update_set}
        WHERE 
            {where_clause}
        RETURNING xmax, {primary_key};
    """
    return query'''

def generate_upsert_query(primary_key, table_name, columns):
    # Génération de la partie VALUES (%s, %s, ...)
    values_placeholders = ', '.join(['%s'] * len(columns))
    # Génération de la partie ON CONFLICT (INDNB) DO UPDATE SET
    update_set = ', '.join([f"{col} = EXCLUDED.{col}" for col in columns[1:]])
    # Génération de la partie WHERE
    where_clause = ' OR '.join([f'public."{table_name}".{col} IS DISTINCT FROM EXCLUDED.{col}' for col in columns[1:]])
    # Requête d'insertion/mise à jour
    query = f"""
        INSERT INTO public."{table_name}" ({', '.join(columns)})
        VALUES ({values_placeholders})
        ON CONFLICT ({primary_key}) DO UPDATE SET
            {update_set}
        WHERE 
            {where_clause}
        RETURNING CASE WHEN xmax = 0 THEN 'insert' ELSE 'update' END AS action, {primary_key};
    """
    return query


