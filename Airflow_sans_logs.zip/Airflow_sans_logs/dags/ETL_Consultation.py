import logging
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from utils.db_utils import connect_to_db, fetch_all_data, insert_or_update_data, get_intersection_values
from utils.etl_utils import generate_upsert_query
import pandas as pd
import os

# Define default arguments
default_args = {
    'owner': 'leopold',
    'start_date': datetime(2024, 6, 21),
}

hostname = 'host.docker.internal'  # adresse du pc et non du conteneur
port = 5432

username = 'postgres'
password = 'postgre'

# Extraction function
def extraction():
    try:
        # Connection à la base de données 'consultation'
        conn_consultation = connect_to_db(hostname, port, 'consultation', username, password)
        logging.info("Connection to PostgreSQL 'consultation' DB successful")

        # Extraction de la table 'Consultation'
        results_consultation = fetch_all_data(conn_consultation, "Consultation")
        logging.info("Fetched results from 'Consultation' table")

        conn_consultation.close()

        # Connection à la base de données 'identite'
        conn_identite = connect_to_db(hostname, port, 'identite', username, password)
        logging.info("Connection to PostgreSQL 'identite' DB successful")

        # Extraction de la table 'Identite'
        results_identite = fetch_all_data(conn_identite, "Identite")
        logging.info("Fetched results from 'Identite' table")

        conn_identite.close()

        return {
            'consultation': results_consultation,
            'identite': results_identite,
        }

    except Exception as e:
        logging.error("Error connecting to PostgreSQL DBs", exc_info=True)
        return {}

# Loading function
def chargement(ti):
    try:
        data = ti.xcom_pull(task_ids='une_simple_extraction')
        if not data:
            logging.error("No data pulled from XCom")
            return
        
        consultation_data = data['consultation']
        identite_data = data['identite']

        # Connection to databases
        conn_datawarehouse = connect_to_db(hostname, port, 'datawarehouse', username, password)
        logging.info("Connection to Data Warehouse DB successful")

        # Récupérer les données aux intersections des 2 tables, ie HOSIN == INDNB
        intersection_values, difference_values = get_intersection_values(0, 2, identite_data, consultation_data)

        # Génération de la requête d'insertion/mise à jour
        columns_consultation = [
            "CSLCR", "CSLNB", "CSLIN", "CSLSV", "CSLPS", "CSLST", "CSLOY", "CSLOM", "CSLOD", "CSLUY", "CSLUM", "CSLUD", "CSLUS"
        ]
        query = generate_upsert_query("CSLNB", "Consultation", columns_consultation)

        # Application de la requête dans la base datawarehouse
        insert_or_update_data(conn_datawarehouse, query, intersection_values) 
        for value in difference_values:
            logging.info(f'error: {value} ne correspond à aucun élément de identite')


        
        # Chemin de sortie 
        output_dir = '/opt/airflow/data/output'
        output_path = os.path.join(output_dir, 'difference_consultation.csv')
        
        difference = pd.DataFrame(difference_values)
        
        # Vérification de l'existence du répertoire de sortie
        difference = pd.DataFrame(difference_values)
        logging.info(f'Dimension de difference: {difference.shape}')
    

        # Enregistrement des données dans le fichier CSV
        logging.info(f"Enregistrement des données dans le fichier CSV : {output_path}")
        try:
            difference.to_csv(output_path, index=False)
            logging.info(f"Les données ont été enregistrées avec succès dans le fichier CSV : {output_path}")
        except Exception as e:
            logging.error(f"Erreur lors de l'enregistrement des données dans le fichier CSV : {e}", exc_info=True)

        conn_datawarehouse.commit()
        conn_datawarehouse.close()
        logging.info("Data loaded into Data Warehouse successfully")

    except Exception as e:
        logging.error("Error loading data into Data Warehouse", exc_info=True)


# Define the DAG, fréquence=toutes les 2 heures
with DAG("ETL_Consultation", default_args=default_args, catchup=False, schedule_interval='0 */2 * * *') as dag:
    extraction_task = PythonOperator(
        task_id='une_simple_extraction',
        python_callable=extraction,
    )
    chargement_task = PythonOperator(
        task_id='un_simple_chargement',
        python_callable=chargement,
    )

extraction_task >> chargement_task
