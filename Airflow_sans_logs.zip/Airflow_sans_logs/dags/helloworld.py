from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago
# Définir une fonction qui affiche "Hello, World!"
def print_hello():
    print("Hello, World!")
# Définir les arguments par défaut pour le DAG
default_args = {
    'owner': 'airflow',
    'start_date': days_ago(1),
    'retries': 1,
}
# Définir le DAG
with DAG(
    'helloworld',
    default_args=default_args,
    description='A simple DAG to print Hello World!',
    schedule_interval=None,  # Ne pas planifier automatiquement (manuellement déclenché)
    catchup=False,
) as dag:
    # Définir la tâche d'impression Hello World
    print_hello_task = PythonOperator(
        task_id='print_hello_task',
        python_callable=print_hello
    )
    # Définir l'ordre des tâches
    print_hello_task
