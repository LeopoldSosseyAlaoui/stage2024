import logging
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from utils.db_utils import connect_to_db, fetch_all_data, insert_or_update_data, extract_date, is_valid_date
from utils.etl_utils import generate_upsert_query
logging.basicConfig(level=logging.ERROR)
# Define default arguments
default_args = {
    'owner': 'leopold',
    'start_date': datetime(2024, 6, 21),
}

hostname = 'host.docker.internal'  # Adresse du PC et non du conteneur
port = 5432
username = 'postgres'
password = 'postgre'

# Extraction function for Identite
def extraction_identite():
    try:
        conn_identite = connect_to_db(hostname, port, 'identite', username, password)
        logging.info("Connection to PostgreSQL DB for 'identite' successful")

        results_identite = fetch_all_data(conn_identite, "Identite")
        logging.info("Fetched results from 'identite' DB")

        conn_identite.close()
        return {'identite': results_identite}

    except Exception as e:
        logging.error("Error connecting to PostgreSQL DBs", exc_info=True)
        return {}

# Loading function for Identite
def chargement_identite(ti):
    try:
        data = ti.xcom_pull(task_ids='extraction_identite')
        if not data:
            logging.error("No data pulled from XCom")
            return
        identite_data = data['identite']
        
        conn_datawarehouse = connect_to_db(hostname, port, 'datawarehouse_en_etoile', username, password)
        logging.info("Connection to Data Warehouse DB successful")
        
        columns = [
            "INDNB", "INDNM", "INDNE", "INDSN", "INDOI", "INDYY", "INDMM", "INDDD", 
            "INDBP", "INDSX", "INDMT", "INDNN", "INDDN", "INDUY", "INDUM", "INDUD", "INDUS"
        ]
        query = generate_upsert_query("INDNB", "DimIdentite", columns)
        
        insert_or_update_data(conn_datawarehouse, query, identite_data)
        conn_datawarehouse.commit()
        conn_datawarehouse.close()
        logging.info("Data loaded into Data Warehouse successfully")
    except Exception as e:
        logging.error("Error loading data into Data Warehouse", exc_info=True)

# Extraction function for Hospitalisation
def extraction_hospitalisation():
    try:
        conn_hospitalisation = connect_to_db(hostname, port, 'hospitalisation', username, password)
        logging.info("Connection to PostgreSQL DB for 'hospitalisation' successful")

        results_hospitalisation = fetch_all_data(conn_hospitalisation, "Hospitalisation")
        logging.info("Fetched results from 'hospitalisation' DB")

        conn_hospitalisation.close()
        return {'hospitalisation': results_hospitalisation}

    except Exception as e:
        logging.error("Error connecting to PostgreSQL DBs", exc_info=True)
        return {}

# Loading function for Hospitalisation
def chargement_hospitlistion(ti):
    try:
        data = ti.xcom_pull(task_ids='extraction_hospitlisation')
        if not data:
            logging.error("No data pulled from XCom")
            return
        hospitalisation_data = data['hospitalisation']
        
        conn_datawarehouse = connect_to_db(hostname, port, 'datawarehouse_en_etoile', username, password)
        logging.info("Connection to Data Warehouse DB successful")
        
        columns_hospitalisation = [
            "HOSNB", "HOSIN", "HOSST", "HOSOY", "HOSOM", "HOSOD", "HOSSY", "HOSSM", 
            "HOSSD", "HOSMO", "HOSRS", "HOSUY", "HOSUM", "HOSUD", "HOSUS"
        ]
        query = generate_upsert_query("HOSNB", "DimHospitalisation", columns_hospitalisation)
        
        insert_or_update_data(conn_datawarehouse, query, hospitalisation_data)
        conn_datawarehouse.commit()
        conn_datawarehouse.close()
        logging.info("Data loaded into Data Warehouse successfully")
    except Exception as e:
        logging.error("Error loading data into Data Warehouse", exc_info=True)

# Extraction function for Consultation
def extraction_consultation():
    try:
        conn_consultation = connect_to_db(hostname, port, 'consultation', username, password)
        logging.info("Connection to PostgreSQL DB for 'consultation' successful")

        results_consultation = fetch_all_data(conn_consultation, "Consultation")
        logging.info("Fetched results from 'consultation' DB")

        conn_consultation.close()
        return {'consultation': results_consultation}

    except Exception as e:
        logging.error("Error connecting to PostgreSQL DBs", exc_info=True)
        return {}

# Loading function for Consultation
def chargement_consultation(ti):
    try:
        data = ti.xcom_pull(task_ids='extraction_consultation')
        if not data:
            logging.error("No data pulled from XCom")
            return
        consultation_data = data['consultation']
        
        conn_datawarehouse = connect_to_db(hostname, port, 'datawarehouse_en_etoile', username, password)
        logging.info("Connection to Data Warehouse DB successful")
        
        columns_consultation = [
            "CSLCR", "CSLNB", "CSLIN", "CSLSV", "CSLPS", "CSLST", "CSLOY", "CSLOM", "CSLOD", 
            "CSLUY", "CSLUM", "CSLUD", "CSLUS"
        ]
        query = generate_upsert_query("CSLNB", "DimConsultation", columns_consultation)
        
        insert_or_update_data(conn_datawarehouse, query, consultation_data)
        conn_datawarehouse.commit()
        conn_datawarehouse.close()
        logging.info("Data loaded into Data Warehouse successfully")
    except Exception as e:
        logging.error("Error loading data into Data Warehouse", exc_info=True)

def insert_FaitMedical():
    conn_consultation = connect_to_db(hostname, port, 'consultation', username, password)
    conn_hospitalisation = connect_to_db(hostname, port, 'hospitalisation', username, password)
    
    hospitalisations = fetch_all_data(conn_hospitalisation, "Hospitalisation")
    consultations = fetch_all_data(conn_consultation, "Consultation")
    
    conn_consultation.close()
    conn_hospitalisation.close()
    
    FaitMedical = []
    Hintegrate = []

    for c in consultations:
        c_integrate = False
        date_consultation = extract_date(c, 6)
        if not is_valid_date(date_consultation):
            
            continue

        for h in hospitalisations:
            date_entree = extract_date(h, 3)
            date_sortie = extract_date(h, 6)
            
            if not (is_valid_date(date_entree) and is_valid_date(date_sortie)):
                
                continue

            if h[1] == c[2]:
                indnb = h[1]
                hosnb = h[0]
                cslnb = c[1]
                id_fait = indnb + hosnb + cslnb if hosnb is not None and cslnb is not None else None
                motif = h[10]
                service = c[3]
                if date_sortie >= date_consultation >= date_entree:
                    FaitMedical.append((id_fait, indnb, hosnb, cslnb, motif, date_entree, date_sortie, service, date_consultation))
                    Hintegrate.append(h)
                c_integrate = True

        if not c_integrate:
            indnb = c[2]
            cslnb = c[1]
            id_fait = indnb + cslnb if cslnb is not None else indnb
            service = c[3]
            FaitMedical.append((id_fait, indnb, None, cslnb, None, None, None, service, date_consultation))

    for h in hospitalisations:
        if h not in Hintegrate:
            indnb = h[1]
            hosnb = h[0]
            id_fait = indnb + hosnb if hosnb is not None else indnb
            motif = h[10]
            date_entree = extract_date(h, 3)
            date_sortie = extract_date(h, 6)
            FaitMedical.append((id_fait, indnb, hosnb, None, motif, date_entree, date_sortie, None, None))

    conn_datawarehouse = connect_to_db(hostname, port, 'datawarehouse_en_etoile', username, password)
    cur = conn_datawarehouse.cursor()


    try:
        columns_faitmedical = [
                "id_fait", "indnb", "hosnb", "cslnb", "motif", 
                "date_entree", "date_sortie", "service", "date"
            ]
        query = generate_upsert_query("id_fait", "FaitMedical", columns_faitmedical)

        insert_or_update_data(conn_datawarehouse, query, FaitMedical)
        conn_datawarehouse.commit()

    except Exception as e:
        conn_datawarehouse.rollback()
        print(f"Erreur lors de l'insertion des données : {e}")

    finally:
        cur.close()
        conn_datawarehouse.close()

# Define the DAG
with DAG(
    "ETL_StarSchema",
    default_args=default_args,
    catchup=False,
    schedule_interval='0 */2 * * *'  # Toutes les 2 heures
) as dag:
    extraction_identite_task = PythonOperator(
         task_id='extraction_identite',
         python_callable=extraction_identite,
    )
    chargement_identite_task = PythonOperator(
         task_id='chargement_identite',
         python_callable=chargement_identite,
    )
    extraction_hospitlisation_task = PythonOperator(
         task_id='extraction_hospitlisation',
         python_callable=extraction_hospitalisation,
    )
    chargement_hospitlisation_task = PythonOperator(
         task_id='chargement_hospitlisation',
         python_callable=chargement_hospitlistion,
    )
    extraction_consultation_task = PythonOperator(
         task_id='extraction_consultation',
         python_callable=extraction_consultation,
    )
    chargement_consultation_task = PythonOperator(
         task_id='chargement_consultation',
         python_callable=chargement_consultation,
    )
    insert_FaitMedical_task = PythonOperator(
        task_id='insert_FaitMedical',
        python_callable=insert_FaitMedical,
    )

# Task dependencies
extraction_identite_task >> chargement_identite_task >> extraction_hospitlisation_task >> chargement_hospitlisation_task >> extraction_consultation_task >> chargement_consultation_task >> insert_FaitMedical_task
