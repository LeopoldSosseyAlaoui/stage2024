import logging
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from utils.db_utils import connect_to_db, fetch_all_data, insert_or_update_data
from utils.etl_utils import generate_upsert_query



# Define default arguments
default_args = {
    'owner': 'leopold',
    'start_date': datetime(2024, 6, 21),
}

hostname = 'host.docker.internal'  # adresse du pc et non du conteneur
port = 5432

username = 'postgres'
password = 'postgre'

# Extraction function
def extraction():
    try:
        # Connections to source databases
        conn_identite = connect_to_db(hostname, port, 'identite', username, password)
        logging.info("Connections to PostgreSQL DBs successful")

        # Extraction des données de la base identite
        results_identite = fetch_all_data(conn_identite, "Identite")

        logging.info("Fetched results from all source DBs")

        conn_identite.close()
        return {
            'identite': results_identite,
        }

    except Exception as e:
        logging.error("Error connecting to PostgreSQL DBs", exc_info=True)
        return {}


# Transformation function (if any transformation is needed)
def transformation(data):
    # Add transformation logic if needed
    transformed_data = data  # Placeholder for transformation logic
    return transformed_data

# Loading function
def chargement(ti):
    try:
        data = ti.xcom_pull(task_ids='une_simple_extraction')
        if not data:
            logging.error("No data pulled from XCom")
            return

        identite_data = transformation(data['identite'])

        # Connection to data warehouse
        conn_datawarehouse = connect_to_db(hostname, port, 'datawarehouse', username, password)
        logging.info("Connection to Data Warehouse DB successful")

         # Liste des colonnes
        columns = [
            "INDNB", "INDNM", "INDNE", "INDSN", "INDOI", "INDYY", "INDMM", "INDDD", 
            "INDBP", "INDSX", "INDMT", "INDNN", "INDDN", "INDUY", "INDUM", "INDUD", "INDUS"
        ]

        # Génération de la requête d'insertion/mise à jour
        query = generate_upsert_query("INDNB", "Identite", columns)

       # Application de la requete dans la base datawarehouse
        insert_or_update_data(conn_datawarehouse, query, identite_data)

        # Commit and close
        conn_datawarehouse.commit()
        conn_datawarehouse.close()


       
        logging.info("Data loaded into Data Warehouse successfully")

    except Exception as e:
        logging.error("Error loading data into Data Warehouse", exc_info=True)

# Define the DAG, fréquence=toutes les 2 heures 'minute, heure, jours, mois, semaine' (cron)
with DAG("ETL_Identite", default_args=default_args, catchup=False, schedule_interval='0 */2 * * *') as dag:
    extraction_task = PythonOperator(
        task_id='une_simple_extraction',
        python_callable=extraction,
    )
    chargement_task = PythonOperator(
        task_id='un_simple_chargement',
        python_callable=chargement,
    )
extraction_task >> chargement_task
